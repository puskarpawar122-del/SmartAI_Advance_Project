# SmartAI — Advanced multi-provider AI workspace

SmartAI is a runnable FastAPI starter application with:
- User registration and login
- Role-based admin dashboard
- AI Chat, Coding, Research and Productivity modes
- Provider selector for OpenAI, Gemini, and Demo mode
- Saved conversations and message history
- Minimalist responsive interface

## Requirements
- Python 3.10+
- Internet access only if using live OpenAI/Gemini APIs

## Setup (Windows PowerShell)

```powershell
cd SmartAI
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `.env` and set a long random `APP_SECRET`. For live AI, add one or both API keys:
- `OPENAI_API_KEY=...`
- `GEMINI_API_KEY=...`

Keep `DEFAULT_AI_PROVIDER=demo` if you want to start without API credentials.

## Run

```powershell
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

Health check: http://127.0.0.1:8000/health

## First admin login

- Email: `admin@smartai.local`
- Password: `ChangeMe123!`

**Immediately change this password before exposing the app to anyone.** This starter seeds the admin on first startup only. For a real deployment, implement an admin password change flow, HTTPS, secure cookies, CSRF protection, rate limiting, email verification, backups, and a managed database.

## AI provider setup

The provider selector in the workspace lets you choose Demo, OpenAI, or Gemini. Only configured providers appear in `/health`; the UI selector is intentionally visible so missing-key errors are clear.

### OpenAI
Create an API key in your OpenAI developer account and set `OPENAI_API_KEY` in `.env`. The default model is `gpt-4o-mini`; change `OPENAI_MODEL` if your account supports another model.

### Gemini
Create a Gemini API key in Google AI Studio and set `GEMINI_API_KEY` in `.env`. The default model is `gemini-2.0-flash`; change `GEMINI_MODEL` if needed.

API usage may incur charges. Never put keys in frontend JavaScript, commit `.env`, or share screenshots containing keys.

## Database
The starter uses SQLite for zero-configuration local development. Data is stored in `smartai.db`. The current database adapter is SQLite-only; `DATABASE_URL` is reserved for future expansion and should remain `sqlite:///./smartai.db`.

## Troubleshooting
- `No module named uvicorn`: activate `.venv`, then run `pip install -r requirements.txt`.
- PowerShell blocks activation: run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.
- Port busy: `uvicorn app.main:app --reload --port 8001`.
- Login/session errors: ensure `APP_SECRET` is set and restart the server.
- Provider key errors: check `.env` spelling, remove quotes around values, and restart.

## Project layout

```text
SmartAI/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── auth.py
│   └── ai_engine.py
├── templates/
├── static/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Notes
This is a learning prototype, not a production-hardened SaaS. Demo mode is rule-based and does not call an LLM or browse the internet. AI responses can be inaccurate; verify important output.
