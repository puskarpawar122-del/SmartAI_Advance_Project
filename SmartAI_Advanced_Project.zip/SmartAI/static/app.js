(() => {
 const form=document.querySelector("#chat-form");
 if(!form) return;
 const body=document.querySelector("#chat-body"), input=document.querySelector("#message");
 const provider=document.querySelector("#provider"), error=document.querySelector("#error-text");
 const send=document.querySelector("#send-button");
 let mode="chat";
 const titles={chat:["AI Chat","A helpful space to think out loud."],coding:["Coding assistant","Learn, generate and debug code."],research:["Research assistant","Structure questions and synthesize findings."],productivity:["Productivity","Turn goals into focused next steps."]};
 function esc(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
 function addMessage(role,text,meta=""){
   const el=document.createElement("div"); el.className="message "+role;
   el.innerHTML=`<div class="message-avatar">${role==="assistant"?"✳":"You"}</div><div class="message-content"><div class="message-meta">${role==="assistant"?"SmartAI":"You"} ${meta?`· ${esc(meta)}`:""}</div><div class="message-text">${esc(text).replace(/\n/g,"<br>")}</div></div>`;
   body.appendChild(el); body.scrollTop=body.scrollHeight;
 }
 document.querySelectorAll(".tool-link").forEach(b=>b.addEventListener("click",()=>{
   document.querySelectorAll(".tool-link").forEach(x=>x.classList.remove("active")); b.classList.add("active");
   mode=b.dataset.mode; document.querySelector("#mode-title").textContent=titles[mode][0]; document.querySelector("#mode-subtitle").textContent=titles[mode][1];
   body.innerHTML=`<div class="welcome-message"><div class="welcome-symbol">✳</div><h2>${titles[mode][0]}</h2><p>${titles[mode][1]}</p></div>`;
 }));
 document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>{input.value=b.dataset.prompt;input.focus();}));
 form.addEventListener("submit",async e=>{
   e.preventDefault(); const message=input.value.trim(); if(!message)return;
   error.textContent=""; addMessage("user",message); input.value=""; send.disabled=true; send.textContent="…";
   const loading=document.createElement("div"); loading.className="typing"; loading.textContent="SmartAI is thinking…"; body.appendChild(loading); body.scrollTop=body.scrollHeight;
   try{
     const res=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,mode,provider:provider.value})});
     const data=await res.json(); loading.remove();
     if(!res.ok) throw new Error(data.detail||"Something went wrong.");
     addMessage("assistant",data.answer,data.provider);
     const recent=document.querySelector("#recent-list"); const item=document.createElement("div"); item.className="recent-item"; item.textContent=message.slice(0,50); recent.prepend(item);
   }catch(err){loading.remove();error.textContent=err.message;}
   finally{send.disabled=false;send.textContent="↑";}
 });
 document.querySelectorAll("[data-conversation]").forEach(b=>b.addEventListener("click",async()=>{
   try{const r=await fetch(`/api/conversations/${b.dataset.conversation}`);const d=await r.json();if(!r.ok)throw new Error(d.detail);
   body.innerHTML="";d.messages.forEach(m=>addMessage(m.role,m.content));}catch(e){error.textContent=e.message;}
 }));
 input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
})();