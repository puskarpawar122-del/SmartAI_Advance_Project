import httpx
from app.config import (
    OPENAI_API_KEY, OPENAI_MODEL, GEMINI_API_KEY, GEMINI_MODEL,
    DEFAULT_AI_PROVIDER
)

SYSTEM_PROMPTS = {
    "chat": "You are SmartAI, a helpful, accurate assistant. Explain clearly and ask clarifying questions when needed.",
    "coding": "You are an expert programming tutor. Provide correct code, explain it step by step, and mention assumptions.",
    "research": "You are a careful research assistant. Structure the answer with key findings, caveats, and useful search terms. Never invent citations.",
    "productivity": "You are a productivity coach. Turn goals into practical, prioritized, realistic action plans."
}

def available_providers():
    providers = ["demo"]
    if OPENAI_API_KEY:
        providers.append("openai")
    if GEMINI_API_KEY:
        providers.append("gemini")
    return providers

async def generate_reply(prompt: str, mode: str = "chat", provider: str | None = None):
    provider = (provider or DEFAULT_AI_PROVIDER or "demo").lower()
    if provider not in ("openai", "gemini", "demo"):
        provider = "demo"
    if provider == "openai":
        if not OPENAI_API_KEY:
            raise ValueError("OpenAI API key is missing. Add OPENAI_API_KEY to your .env file.")
        headers = {"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"}
        payload = {
            "model": OPENAI_MODEL,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPTS.get(mode, SYSTEM_PROMPTS["chat"])},
                {"role": "user", "content": prompt}
            ],
            "temperature": 0.5
        }
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
        return data["choices"][0]["message"]["content"], "openai"
    if provider == "gemini":
        if not GEMINI_API_KEY:
            raise ValueError("Gemini API key is missing. Add GEMINI_API_KEY to your .env file.")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"
        payload = {
            "systemInstruction": {"parts": [{"text": SYSTEM_PROMPTS.get(mode, SYSTEM_PROMPTS["chat"])}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.5}
        }
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            data = response.json()
        text = "".join(part.get("text", "") for part in data["candidates"][0]["content"]["parts"])
        return text, "gemini"
    return demo_reply(prompt, mode), "demo"

def demo_reply(prompt: str, mode: str) -> str:
    p = prompt.strip()
    if mode == "coding":
        return (
            "## Demo coding response\\n\\n"
            "I’m running in **Demo mode**, so no external model was called. Here is a useful workflow:\\n"
            "1. Clarify the expected input and output.\\n2. Write the smallest working solution.\\n"
            "3. Test normal, edge and invalid inputs.\\n4. Refactor and document it.\\n\\n"
            f"**Your request:** {p}\\n\\n"
            "Add an OpenAI or Gemini API key in `.env` to receive generated code and debugging help."
        )
    if mode == "research":
        return (
            "## Research plan (Demo mode)\\n\\n"
            f"**Topic:** {p}\\n\\n"
            "- Define the research question and scope.\\n"
            "- Collect information from primary and trusted sources.\\n"
            "- Compare evidence and note disagreements.\\n"
            "- Summarize findings and list open questions.\\n\\n"
            "Demo mode does not browse the web or verify sources. Configure an AI provider for AI-generated synthesis."
        )
    if mode == "productivity":
        return (
            "## Action plan (Demo mode)\\n\\n"
            f"**Goal:** {p}\\n\\n"
            "1. Break the goal into small tasks.\\n2. Identify the next 15-minute action.\\n"
            "3. Set a realistic deadline.\\n4. Review progress at the end of the day.\\n\\n"
            "Configure OpenAI or Gemini in `.env` for personalized AI planning."
        )
    return (
        "## Welcome to SmartAI! 👋\\n\\n"
        f"You said: **{p}**\\n\\n"
        "I’m currently using Demo mode. You can explore the interface and workflows without an API key. "
        "To enable live AI responses, add an OpenAI or Gemini API key to `.env`, restart the server, and choose that provider."
    )
