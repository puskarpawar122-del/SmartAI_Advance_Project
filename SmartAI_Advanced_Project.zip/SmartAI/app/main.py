from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from passlib.exc import UnknownHashError
from app.config import APP_SECRET
from app.database import init_db, get_db
from app.auth import hash_password, verify_password
from app.ai_engine import generate_reply, available_providers
import os

app = FastAPI(title="SmartAI", description="Multi-provider AI productivity platform")
app.add_middleware(SessionMiddleware, secret_key=APP_SECRET, same_site="lax", https_only=False)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.on_event("startup")
def startup():
    init_db()
    with get_db() as db:
        admin = db.execute("SELECT id FROM users WHERE role='admin' LIMIT 1").fetchone()
        if not admin:
            db.execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                       ("SmartAI Admin", "admin@smartai.local", hash_password("ChangeMe123!"), "admin"))

def current_user(request: Request):
    uid = request.session.get("user_id")
    if not uid:
        return None
    with get_db() as db:
        row = db.execute("SELECT id,name,email,role FROM users WHERE id=?", (uid,)).fetchone()
        return dict(row) if row else None

def page(request, name, **context):
    return templates.TemplateResponse(name, {"request": request, "user": current_user(request),
                                               "providers": available_providers(), **context})

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    if current_user(request):
        return RedirectResponse("/dashboard", status_code=303)
    return page(request, "landing.html")

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    return page(request, "register.html")

@app.post("/register")
async def register(request: Request, name: str = Form(...), email: str = Form(...), password: str = Form(...)):
    if len(password) < 8:
        return page(request, "register.html", error="Password must be at least 8 characters.")
    try:
        with get_db() as db:
            db.execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'user')",
                       (name.strip(), email.strip().lower(), hash_password(password)))
            uid = db.execute("SELECT id FROM users WHERE email=?", (email.strip().lower(),)).fetchone()["id"]
    except Exception:
        return page(request, "register.html", error="That email is already registered.")
    request.session["user_id"] = uid
    return RedirectResponse("/dashboard", status_code=303)

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return page(request, "login.html")

@app.post("/login")
async def login(request: Request, email: str = Form(...), password: str = Form(...)):
    with get_db() as db:
        row = db.execute("SELECT * FROM users WHERE email=?", (email.strip().lower(),)).fetchone()
    if not row or not verify_password(password, row["password_hash"]):
        return page(request, "login.html", error="Invalid email or password.")
    request.session["user_id"] = row["id"]
    return RedirectResponse("/dashboard", status_code=303)

@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=303)

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    user = current_user(request)
    if not user:
        return RedirectResponse("/login", status_code=303)
    with get_db() as db:
        chats = db.execute("""SELECT c.id,c.title,c.mode,c.provider,c.created_at,
          (SELECT content FROM messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) last_message
          FROM conversations c WHERE c.user_id=? ORDER BY c.id DESC LIMIT 12""", (user["id"],)).fetchall()
    return page(request, "dashboard.html", conversations=[dict(x) for x in chats])

@app.post("/api/chat")
async def chat(request: Request):
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Please log in.")
    data = await request.json()
    prompt = str(data.get("message", "")).strip()
    mode = str(data.get("mode", "chat")).lower()
    provider = str(data.get("provider", "demo")).lower()
    if not prompt:
        raise HTTPException(status_code=400, detail="Message cannot be empty.")
    if len(prompt) > 12000:
        raise HTTPException(status_code=400, detail="Message is too long (12,000 character limit).")
    if mode not in ("chat", "coding", "research", "productivity"):
        mode = "chat"
    try:
        answer, used_provider = await generate_reply(prompt, mode, provider)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    title = prompt[:55] + ("…" if len(prompt) > 55 else "")
    with get_db() as db:
        cur = db.execute("INSERT INTO conversations(user_id,title,mode,provider) VALUES(?,?,?,?)",
                         (user["id"], title, mode, used_provider))
        cid = cur.lastrowid
        db.execute("INSERT INTO messages(conversation_id,role,content) VALUES(?,?,?)", (cid, "user", prompt))
        db.execute("INSERT INTO messages(conversation_id,role,content) VALUES(?,?,?)", (cid, "assistant", answer))
    return JSONResponse({"answer": answer, "provider": used_provider, "conversation_id": cid})

@app.get("/api/conversations/{conversation_id}")
async def get_conversation(request: Request, conversation_id: int):
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Please log in.")
    with get_db() as db:
        chat = db.execute("SELECT * FROM conversations WHERE id=? AND user_id=?",
                          (conversation_id, user["id"])).fetchone()
        if not chat:
            raise HTTPException(status_code=404, detail="Conversation not found.")
        messages = db.execute("SELECT role,content,created_at FROM messages WHERE conversation_id=? ORDER BY id",
                              (conversation_id,)).fetchall()
    return {"conversation": dict(chat), "messages": [dict(m) for m in messages]}

@app.get("/admin", response_class=HTMLResponse)
async def admin(request: Request):
    user = current_user(request)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin access required.")
    with get_db() as db:
        users = db.execute("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC").fetchall()
        total_chats = db.execute("SELECT COUNT(*) n FROM conversations").fetchone()["n"]
        total_messages = db.execute("SELECT COUNT(*) n FROM messages").fetchone()["n"]
    return page(request, "admin.html", users=[dict(x) for x in users],
                total_chats=total_chats, total_messages=total_messages)

@app.get("/health")
async def health():
    return {"status": "ok", "app": "SmartAI", "providers": available_providers()}
